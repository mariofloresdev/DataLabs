package linkedLists;
/**
 * Singly linked list with references to its first and its
 * last node. 
 * 
 * @author pirvos
 *
 */

import linkedLists.LinkedList;

public class SLFLList<E> 
implements LinkedList<E>
{

	private SNode<E> first, last; 
	int length = 0; 

	public SLFLList() { 
		first = last = null; 
	}


	public void addFirstNode(Node<E> nuevo) {
		// TODO Auto-generated method stub
		SNode<E> node = (SNode<E>) nuevo;//convert it
		if(first==null){ //if list is empty
			first = last = node; //first and last are both the new node
		}
		else{
			node.setNext(first); //node goes before first
			first = node; //so first is node now
		}
		//System.out.println(node.getElement());
		length++;
	}

	public void addNodeAfter(Node<E> target, Node<E> nuevo) {
		// TODO Auto-generated method stub
		SNode<E> node = (SNode<E>) nuevo, targ = (SNode<E>) target; //converts both of them
		node.setNext(targ.getNext()); //node next is the node next to target
		targ.setNext(node); //target new next node is node
		if(target == last) last =node;
		length++;
	}

	public void addNodeBefore(Node<E> target, Node<E> nuevo) {
		// TODO Auto-generated method stub
		if(target==first){
			this.addFirstNode(nuevo);
		}
		else{
			SNode<E> prev = (SNode<E>)this.getNodeBefore(target);
			this.addNodeAfter(prev, nuevo);
		}
	}

	public Node<E> getFirstNode() throws NodeOutOfBoundsException {
		// TODO Auto-generated method stub
		return first;
	}

	public Node<E> getLastNode() throws NodeOutOfBoundsException {
		// TODO Auto-generated method stub
		return last;
	}

	public Node<E> getNodeAfter(Node<E> target) throws NodeOutOfBoundsException {
		// TODO Auto-generated method stub
		SNode<E> targ =(SNode<E>) target;
		return targ.getNext();
	}

	public Node<E> getNodeBefore(Node<E> target)
			throws NodeOutOfBoundsException {
		// TODO Auto-generated method stub
		if(target==first) return null;
		SNode<E> curr;
		curr = first;
		while(curr!=null && curr.getNext()!=target){
			curr = curr.getNext();
		}
		
		return curr;
	}

	public int length() {
		// TODO Auto-generated method stub
		return length;
	}

	public void removeNode(Node<E> target) {
		// TODO Auto-generated method stub
		//just remove, don't clean it
		SNode<E> prev = (SNode<E>) this.getNodeBefore(target), targ = (SNode<E>) target;
		if(targ==first){
			first =targ.getNext();
			targ.setNext(null);
		}
		else{
		if(targ == last){
			last = prev;
		}
		prev.setNext(targ.getNext());
		targ.setNext(null);//keeps the data
		}
		length--;

	}

	public Node<E> createNewNode() {
		return new SNode<E>();
	}
	
	public Node<E> createNewNode(E e){
		SNode<E> node = new SNode<>();
		node.setElement(e);
		return node;
	}


	///////////////////////////////////////////////////
	// private and static inner class that defines the 
	// type of node that this list implementation uses
	private static class SNode<T> implements Node<T> {
		private T element; 
		private SNode<T> next; 
		public SNode() { 
			element = null; 
			next = null; 
		}
		public SNode(T data, SNode<T> next) { 
			this.element = data; 
			this.next = next; 
		}
		public SNode(T data)  { 
			this.element = data; 
			next = null; 
		}
		public T getElement() {
			return element;
		}
		public void setElement(T data) {
			this.element = data;
		}
		public SNode<T> getNext() {
			return next;
		}
		public void setNext(SNode<T> next) {
			this.next = next;
		}
	}

}
