package testers;
import linkedLists.SLFLList;
import linkedLists.Node;

public class SLFTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SLFLList<Integer> list = new SLFLList<>();
		Node<Integer> n3, n5, n8, n10;
		list.addFirstNode(n3 = list.createNewNode(3));
		
		list.addFirstNode(n5 = list.createNewNode(5));
		
		list.addNodeAfter(list.getLastNode() , n8 =  list.createNewNode(8));
		
		list.addNodeBefore(n5, n10 = list.createNewNode(10));
		
		System.out.println(list.getFirstNode().getElement()+"-"+list.getLastNode().getElement());
		printElements(list);
		list.removeNode(n10);
		list.removeNode(n8);
		System.out.println();
		printElements(list);
		
		System.out.println("Size "+ list.length());
	}
	
	private static void printElements(SLFLList<Integer> list){
		Node<Integer> n = list.getFirstNode(), curr = n;
		
			while(n!=null){
				System.out.println(n.getElement());
				curr = list.getNodeAfter(n);
				n = curr;
				
			}
		
		
	}
	

}
